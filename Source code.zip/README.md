README

Step 0

Install environment

* Python 2.6+
* pip
* Virtualenv

Step 1

Create virtual environment, and use 

	pip install -r requirement.txt

to install all modules necessary.

Step 2

Enter into main folder and run

	python tsp.py

to see result.
